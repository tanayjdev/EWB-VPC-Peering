# AWS VPC Peering — Private Cross-VPC Communication

**Student:** Tanay Jain  
**AICTE Student ID:** STU970f6f93295d91789482176  
**College:** Birla Institute of Technology, Mesra (Jaipur Campus)  
**Internship:** Amazon Web Services (AWS) Cloud Computing Internship (EWB Edutech Pvt. Ltd.)  
**AWS Region:** `ap-south-1 (Mumbai)`  
**Completion date:** 19 October 2026

## Project summary

This hands-on project connects two non-overlapping AWS VPCs using VPC peering and validates private IPv4 connectivity between two private EC2 workloads. VPC A also contains a public bastion host for administration. The report records the as-built network during testing and the cleanup state afterward.

## Architecture at validation time

![EWB VPC Peering architecture](02_Architecture/EWB_VPC_Peering_Architecture.jpg)

- VPC A `ewb-vpc-a`: `10.10.0.0/16`
- Public subnet `ewb-a-public`: `10.10.1.0/24`; bastion `10.10.1.10`, public IPv4 at test time `13.232.128.100`
- Private subnet `ewb-a-private`: `10.10.2.0/24`; App-A `10.10.2.10`, no public IPv4
- VPC B `ewb-vpc-b`: `10.20.0.0/16`
- Private subnet `ewb-b-private`: `10.20.1.0/24`; App-B `10.20.1.10`, no public IPv4
- Internet Gateway: `igw-0eb224e3fb0322445`
- VPC peering: `pcx-03d90d239a4ae9a9b` (`Active` during validation; project resources were removed during cleanup)

## Resource inventory

| Resource | AWS identifier |
|---|---|
| VPC A | `vpc-0a6ce73ff02b1503f` |
| VPC B | `vpc-075df51206347c58f` |
| Public subnet A | `subnet-0484e07086d26edb5` |
| Private subnet A | `subnet-0d7771459ff9a714d` |
| Private subnet B | `subnet-0b71be209ac84f3f3` |
| Public route table A | `rtb-07eb6affd6f3a0e73` |
| Private route table A | `rtb-0e0dde41748dfa436` |
| Private route table B | `rtb-0dfff1ec80beab2f9` |
| Bastion security group | `sg-0dd786e889c8dc6c9` |
| App-A security group | `sg-06ebed5e7197ab5d5` |
| App-B security group | `sg-0ef25547ef3d026e5` |
| Bastion EC2 | `i-0a96fe6409821ab86` |
| App-A EC2 | `i-07875dafbce902beb` |
| App-B EC2 | `i-077af8fdd52fd6b4a` |

The lifecycle IDs above describe resources at the time of testing. The post-cleanup evidence shows the three instances terminated and the project VPCs absent from the displayed VPC list.

## Route-table design

| Route table | Destination | Target |
|---|---|---|
| `ewb-rt-a-public` | `10.10.0.0/16` | `local` |
| `ewb-rt-a-public` | `0.0.0.0/0` | `igw-0eb224e3fb0322445` |
| `ewb-rt-a-public` | `10.20.0.0/16` | `pcx-03d90d239a4ae9a9b` |
| `ewb-rt-a-private` | `10.10.0.0/16` | `local` |
| `ewb-rt-a-private` | `10.20.0.0/16` | `pcx-03d90d239a4ae9a9b` |
| `ewb-rt-b-private` | `10.20.0.0/16` | `local` |
| `ewb-rt-b-private` | `10.10.0.0/16` | `pcx-03d90d239a4ae9a9b` |

## Security model

- Bastion SSH: TCP/22 from a single public IPv4 `/32` source shown in the evidence at capture time.
- App-A SSH: TCP/22 from `10.10.1.10/32`; ICMP Echo Request from `10.20.1.10/32`.
- App-B SSH: TCP/22 from `10.10.1.10/32`; ICMP Echo Request from `10.10.2.10/32`.
- App-A and App-B had no public IPv4 address.
- The key file is kept on the student workstation; no private key is included in this repository. `configs/ssh_config` only references the local key path.

## Validation results

| Test | Observed result |
|---|---|
| `ssh ewb-bastion` | Successful |
| `ssh ewb-app-a` through ProxyJump | Successful |
| `ssh ewb-app-b` through ProxyJump | Successful |
| App-A `ping -c 4 10.20.1.10` | 4 received, 0% packet loss |
| App-B `ping -c 4 10.10.2.10` | 4 received, 0% packet loss |
| Controlled ICMP failure after removing App-B Echo Request from `10.10.2.10/32` | 0 received, 100% packet loss |
| Recovery after restoring the rule | 4 received, 0% packet loss |

### Baseline evidence disclosure

The original pre-peering baseline ping failure was not captured before peering was activated. It was not fabricated retrospectively. The post-peering controlled negative test and recovery demonstrate that the destination security-group ICMP rule controls reachability; they are not claimed to be the original baseline test.

## Cleanup status and limitations

Evidence shows the three EC2 instances in `Terminated` state and the VPC list showing the default VPC only. The evidence archive does not include post-cleanup EBS volume, Elastic IP allocation, or Billing pages; therefore this repository does not claim that all possible residual chargeable resources have been cleared or that billing is zero. Verify volumes, snapshots, Elastic IPs and Billing independently. Do not delete unrelated pre-existing practice resources.

## Repository structure

```text
EWB_VPC_Peering_Submission/
├── README.md
├── FINAL_SUBMISSION_CHECKLIST.txt
├── configs/
│   └── ssh_config
├── 01_Report/
│   ├── Tanay_Jain_EWB_VPC_Peering.docx
│   └── Tanay_Jain_EWB_VPC_Peering.pdf
├── 02_Architecture/
│   └── EWB_VPC_Peering_Architecture.jpg
└── 03_Evidence_Screenshots/
    └── 22 original evidence screenshots
```

## Run the SSH config (historical reference)

Copy `configs/ssh_config` into the local OpenSSH config file only if you recreate the lab. The public IP in the config is the value recorded during this project and can change or be reassigned; confirm the current bastion IP before use. Place the original private key at `~/.ssh/ewb-lab.pem` on your own machine and never commit it.

## Mandatory viva notes

1. **Return route:** Peering does not add routes automatically; the destination-side route table must know how to reach the source CIDR for responses.
2. **Bastion source IP:** ProxyJump creates a separate connection from the bastion to App-B, so App-B sees the bastion private IP `10.10.1.10`.
3. **Active peering vs ping:** routes, security groups, network ACLs, host firewalls and host state still govern reachability.
4. **VPC B internet access:** VPC peering is non-transitive and does not make VPC A's Internet Gateway a transit egress path for VPC B.
